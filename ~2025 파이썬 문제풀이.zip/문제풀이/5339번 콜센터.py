# 5339번 콜센터

print("     /~\\")
print("    ( oo|")
print("    _\\=/_")
print("   /  _  \\")
print("  //|/.\\|\\\\")
print(" ||  \\ /  ||")
print("============")
print("|          |")
print("|          |")
print("|          |")